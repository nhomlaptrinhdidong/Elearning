<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class tai_khoan_bai_dangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
